document.querySelector("form").addEventListener("submit", validateForm);

function validateForm(){
    event.preventDefault();
    const name= document.getElementById("name").value ;
    const email= document.getElementById("email").value ;
    const password= document.getElementById("password").value ;
    //console.log(name,email,password);
    emailvaildator(email);
    checkPassword(password);
    
}

function emailvaildator(email){
    let emailarr=[];
    for(let i=0 ;i<email.length;i++){
        emailarr.push(email[i])
    }
    const dot= email.trim().split(".");
    var domain= dot[dot.length-1];
    var chk= "."+dot[dot.length-1];
    
    //console.log(chk)
    // console.log(emailarr)
    

    if(!emailarr.includes("@")){
        alert("@ is not present")
    }
    else if(email.includes("@.")){
        alert("Domain can not start with dot .")
    }
    else if(emailarr[0]=="@"){
        alert("No character before @")
    }
    else if(chk!=".com" && chk !==".org" && chk !==".in" ){
        alert(`${chk}  is not a valid tld `)
    }
    else if(emailarr[0]=="."){
        alert(`An email should not be start with .`)
    }else if(email.includes("..")){
        alert("Double dots are not allowed")
    }else if(checkEmailChar(email)){
        alert("Only allows character, digit, underscore, and dash ")
    }
    else{
        alert("Email Verified")
    }
};

function checkEmailChar(email){
    let count=0;
    let notaalowchar=["(" ,")","{","}","]","[","*","*","&","%","$"];
    for(let i=0 ; i<email.length;i++){
        for(let j=0 ; j<notaalowchar.length;j++){
            if(email[i]==notaalowchar[j]){
                count++
            }
        }
    }
    if(count>0){
        return true;
    }else{
        return false;
    }
}



function checkPassword(password){
    if(password.length<6){
        alert("Length of password should be greater than 6")
    }else if(!checkpass(password)){
        alert("At-least one uppercase alphabet password.")
    }else if(!numericchk(password)){
        alert("At-least one numeric value must be used in the password.")
    }else if(alphachek(password)){
        alert("Only alphanumeric inputs are accepted in the password field")
    }
    else{
        alert("Password verified")
    }
}

function checkpass(str){
    var upperCase= ["A","B","C","D","E","F","G","H","I","J",
                    "K","L","M","N","O","P","Q","R","S","T","U",
                    "V", "W","X", "Y","Z"]
    let count=0;
    for(let i=0 ; i<str.length;i++){
        for(let j=0 ; j<upperCase.length;j++){
            if(str[i]==upperCase[j]){
                count++
            }
        }
    }
    if(count<1){
        return false
    }else{
        return true
    }
}

function numericchk(pass){
    let numarr=[0,1,2,3,4,5,6];
    let count=0;
    for(let i=0 ; i<pass.length;i++){
        for(let j=0 ; j<numarr.length;j++){
            if(pass[i]== numarr[j]){
                count++
            }
        }
    }
    if(count<1){
        return false;
    }else{
        return true ;
    }
}

function alphachek(password){
    let char=["@","#","$","*","/","^","_",];
    let count=0;
    for(let i=0 ; i<password.length;i++){
        for(let j=0 ; j<char.length;j++){
            if(password[i]==char[j]){
                count++
            }
        }
    }
    if(count<1){
        return false
    }else{
        return true
    }
}
